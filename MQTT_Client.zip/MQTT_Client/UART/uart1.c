/*

 * UART_Driver.c
 *
 *  Created on: May 17, 2019
 *      Author: GJF-Trabajo
 */

#include "uart1.h"

#include <LPC845.h>
#include "tipos.h"
#include "gpio.h"

UART1_Struct		UART1;
uint8_t leds[3] = {0};
uint8_t ledActividad = 0;


/*****************************************************************************
** Function name:		UART1_IRQHandler
**
** Descriptions:		UART interrupt handler
**
** parameters:			None
** Returned value:		None
**
*****************************************************************************/
void UART1_IRQHandler (void)
{
	int32_t Temporal;

	uint32_t	Int = USART1->STAT;

	if(Int & (1 << 0))
	{
		//RX
		Temporal = (int32_t)USART1->RXDAT;
		UART1_PushRx((uint8_t)Temporal);

	}

	if(Int & (1 << 2))
	{
		//TX
		Temporal = UART1_PopTx();
		if(Temporal >= 0)
			USART1->TXDAT = (uint8_t)Temporal;
		else
		{
			USART1->INTENCLR = (1 << 2); //disable int TX
			UART1.TX.Datos_Validos = 0;
		}

	}


}


void Inicializar_UART1(uint32_t baudrate)
{
	IOCON_config_t	Temporal;

	Temporal.open_drain = 0;
	Temporal.mode = PULL_UP;
	Temporal.clk_sel = IOCON_CLK_DIV_0;
	Temporal.iic_mode = 0;
	Temporal.dac_mode = 0;
	Temporal.sample_mode = 0;

	IOCON_config_io(IOCON_INDEX_PIO0_0, &Temporal);
	GPIO_Dir( PIN_ENABLE485, 1 );
	GPIO_Set( PIN_ENABLE485, 0 );							//ENABLE 485

	SYSCON->SYSAHBCLKCTRL0 |= (1 << 15);							// 15 = UART1

	//SWM0->PINASSIGN.PINASSIGN1 = (0x24 << 8) | (23 << 16);			// TX1 = P1.4	RX1 = P0.23
	SWM0->PINASSIGN.PINASSIGN1 = (0x10 << 8) | (0x11 << 16);			// TX1 = P0.16	RX1 = P0.17
	USART1->CFG = 	(0)				// 0=DISABLE 1=ENABLE
					| (1 << 2)		// 0=7BITS 1=8BITS 2=9BITS
					| (0 << 4)		// 0=NOPARITY 2=PAR 3=IMPAR
					| (0 << 6)		// 0=1BITSTOP 1=2BITSTOP
					| (0 << 9)		// 0=NOFLOWCONTROL 1=FLOWCONTROL
					| (0 << 11)		// 0=ASINCRONICA 1=SINCRONICA
					| (0 << 14);	// 0=SLAVE 1=MASTER


	USART1->CTL = 0;

	USART1->INTENSET = (1 << 0);	//RX Y TX INTERRUPT

	UART1CLKSEL = 1;

	USART1->BRG = (FREQ_PRINCIPAL / baudrate) / 16;

	NVIC->ISER[0] = (1 << 4); /* enable interrupt */

	USART1->CFG |= 	(1);			// ENABLE USART1

	return;
}

void UART1_Send(uint8_t *Datos, uint32_t Tamanio)
{
	uint32_t i;

	/*if(0 == Tamanio)
		Tamanio = CADENAS_Strlen(Datos);
	*/
	for(i = 0 ; i < Tamanio ; i++)
		UART1_PushTx(Datos[i]);

	return;
}


void UART1_PushTx(uint8_t dato)
{
	UART1.TX.Buffer[UART1.TX.Indice_in] = dato;

	UART1.TX.Indice_in ++;
	UART1.TX.Indice_in %= UART1_TAMANIO_COLA_TX;

	if ( UART1.TX.Datos_Validos == 0 )
	{
		UART1.TX.Datos_Validos = 1;

		USART1->TXDAT = (uint8_t)UART1_PopTx();

		USART1->INTENSET = (1 << 2); // int tx
	}
}

int32_t UART1_PopTx( void )
{
	int32_t dato = -1;

	if ( UART1.TX.Indice_in != UART1.TX.Indice_out )
	{
		dato = (int32_t) UART1.TX.Buffer[UART1.TX.Indice_out];
		UART1.TX.Indice_out ++;
		UART1.TX.Indice_out %= UART1_TAMANIO_COLA_TX;
	}
	return dato;
}

void UART1_PushRx(uint8_t dato)
{
	UART1.RX.Buffer[UART1.RX.Indice_in] = dato;

	UART1.RX.Indice_in ++;
	UART1.RX.Indice_in %= UART1_TAMANIO_COLA_RX;
}

int32_t UART1_PopRx( void )
{
	int32_t dato = -1;

	if ( UART1.RX.Indice_in != UART1.RX.Indice_out )
	{
		dato = (int32_t) UART1.RX.Buffer[UART1.RX.Indice_out];
		UART1.RX.Indice_out ++;
		UART1.RX.Indice_out %= UART1_TAMANIO_COLA_RX;
	}
	return dato;
}

uint32_t MyPow(uint8_t base, uint8_t exponente)
{
	unsigned long retorno = 1;
	if( exponente == 0 )
		return retorno;

	while(exponente)
	{
		retorno *= base;
		exponente --;
	}

	return retorno;
}


void AnalizarTramaUart1(uint8_t dato)
{
		static uint8_t estado = 0, chk = 0;
		switch( estado )
		{
		case 0:
			if( dato == '>'){
				estado = 1;
				chk = dato;
			}else
				estado = 0;

			break;

		case 1:
			if( dato == 'L'){
				estado = 2;
				chk ^= dato;
			}else{
				estado = 0;
				chk = 0;
			}
			break;

		case 2:
			if( dato == ',')
			{
				estado = 3;
				chk ^= dato;
			}
			else{
				estado = 0;
				chk = 0;
			}
			break;

		case 3:
			if( dato == 'R' || dato == 'G' || dato == 'B' )
			{
				if( dato == 'R' )
					leds[0] = 1;
				if( dato == 'G' )
					leds[1] = 1;
				if( dato == 'B' )
					leds[2] = 1;
				estado = 4;
				chk ^= dato;
			}
			else{
				estado = 0;
				chk = 0;
			}
			break;
		case 4:
			if( dato == ',')
			{
				estado = 5;
				chk ^= dato;
			}
			else{
				estado = 0;
				chk = 0;
				leds[0] = leds[1] = leds[2] = 0;
			}
			break;

		case 5:
			if( dato == '0' || dato == '1' )
			{
				if( dato == '0' )
					ledActividad = 1;		//OFF

				if( dato == '1' )
					ledActividad = 0;		//ON
				estado = 6;
				chk ^= dato;
			}
			else{
				estado = 0;
				chk = 0;
				leds[0] = leds[1] = leds[2] = 0;
			}
			break;

		case 6:
			if( dato == ',' )
			{
				estado = 7;
				chk ^= dato;
			}
			else{
				estado = 0;
				chk = 0;
				leds[0] = leds[1] = leds[2] = 0;
			}
			break;

		case 7:		//Chequeo de Checksum
			if( dato == chk )
			{
				estado = 8;
				chk = 0;
			}
			else{
				estado = 0;
				chk = 0;
				leds[0] = leds[1] = leds[2] = 0;
			}
			break;

		case 8:		//Fin de trama <
			if( dato == '<' )
			{
				estado = 0;

				if( leds[0] ){	//Rojo
					if( ledActividad )
						GPIO_Set( PIN_ROJO, LED_OFF );
					else
						GPIO_Set( PIN_ROJO, LED_ON );
					leds[0] = 0;
					UART1_Send((uint8_t *)">R,OK<", 7);
				}

				if( leds[1] ){	//Verde
					if( ledActividad )
						GPIO_Set( PIN_VERDE, LED_OFF );
					else
						GPIO_Set( PIN_VERDE, LED_ON );
					leds[1] = 0;
					UART1_Send((uint8_t *)">G,OK<", 7);
				}

				if( leds[2] ){	//Azul
					if( ledActividad )
						GPIO_Set( PIN_AZUL, LED_OFF );
					else
						GPIO_Set( PIN_AZUL, LED_ON );
					leds[2] = 0;
					UART1_Send((uint8_t *)">B,OK<", 7);
				}
			}
			else{
				estado = 0;
				chk = 0;
				leds[0] = leds[1] = leds[2] = 0;
			}
			break;
		default:
			estado = 0;
			chk = 0;
			break;
		}

}


uint8_t LeerBufferRX( void )
{
	uint8_t caracter;

	caracter = UART1_PopRx();

		if ( caracter == NO_KEY )
			return NO_KEY;

	return caracter;
}
