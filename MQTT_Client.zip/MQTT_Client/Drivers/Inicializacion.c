/*
 * Inicializacion.c
 *
 *  Created on: 16 ago. 2021
 *      Author: mariano
 */
#include <mqtt_client.h>

void Inicializar( void )
{

	Inicializar_PLL( );
	Inicializar_SysTick( FREQ_PRINCIPAL / FREQ_SYSTICK );
    Inicializar_GPIO( );
    Inicializar_CTimer0();
    Inicializar_ADC( );
    //Inicializar_IO();
    Inicializar_UART1(9600);
    //Inicializar_LCD(  );


}
