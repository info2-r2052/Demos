/*
 * DRIVER_ADC.h
 *
 *  Created on: Jan 3, 2020
 *      Author: GJF-Trabajo
 */

#ifndef DRIVER_ADC_DRIVER_ADC_H_
#define DRIVER_ADC_DRIVER_ADC_H_
#include <LPC845.h>

void Inicializar_ADC(void);
void ADC_Disparo(uint8_t Canal);
uint32_t ADC_GetCuentas( void );
extern uint32_t	ADC_Cuentas;
#endif /* DRIVER_ADC_DRIVER_ADC_H_ */
