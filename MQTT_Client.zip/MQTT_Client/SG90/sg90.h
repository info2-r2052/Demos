/*
 * sg90.h
 *
 *  Created on: 15 dic. 2019
 *      Author: juliancho
 */


#define HTML1			"<!DOCTYPE html><html><body><h1>UTN.BA INFO II</h1><h2>R2052</h2><p>Prueba NodeMCU</p><p>"
#define HTML2			"</p><title>UTN.BA INFO II</title></body></html<>"



uint32_t Senoidal(int16_t);
void InitSenoidal(void);
