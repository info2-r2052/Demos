/*
 * ctimer.h
 *
 *  Created on: 7 may. 2021
 *      Author: mariano
 */

#ifndef CTIMER_H_
#define CTIMER_H_

#include <mqtt_client.h>
#include "gpio.h"
#include "io.h"
#include "tipos.h"


//#define MATCH0		24		//IRQ=7,5us
//#define MATCH0		852	//IRQ=35,511us -> 64 samples 2,7272ms - 440Hz
#define MATCH0		23400UL	//1ms

#define 	MINpWM	0
#define		PERIODOtIMER0	1200
#define		CANTdUTIES		10



#define	PWM_OUT0 	0,8
#define	PWM_OUT1 	0,9
#define	ON			1
#define	OFF			0


void Inicializar_CTimer0( void );
uint8_t GetFinPeriodo( void );
void SetFinPeriodo( uint8_t );

#endif /* CTIMER_H_ */
