/*
 * ctimer.c
 *
 *  Created on: 7 may. 2021
 *      Author: mariano
 */
#include "ctimer.h"
#include "adc.h"

volatile uint32_t bufferPWM;
uint8_t volatile finPeriodo;
//const uint32_t duty[CANTdUTIES] = {37400, 108510, 169000, 212970, 236070, 236070, 212970, 169000, 108510, 37400};
const uint8_t duty[CANTdUTIES] = {16, 45, 70, 89, 98, 98, 89, 70, 45, 16};
//const uint8_t duty[CANTdUTIES] = {66, 0, 100, 60, 100, 96, 100, 60, 66, 0};

void CTIMER0_IRQHandler(void)
{
	CTIMER0->IR |= (1 << 0);					// Reset flag MROint
	CTIMER0->TCR |= (1 << 1 );					//reset
	ADC_Disparo(0);								//Canal 0 ADC Pote PI0.7
	CTIMER0->TCR &= ~(1 << 1 );					//No reset
}

void Inicializar_CTimer0( void )
{
	SYSCON->SYSAHBCLKCTRL0 |= (1 << 25);		// 25= CTIMER0
	SYSCON->PRESETCTRL0 |= (1 << 25);			// 25= CTIMER0 clear the timer reset
	CTIMER0->TCR |= (1 << 1 );					//reset
	CTIMER0->TCR |= (1 << 0);					//Enable
	CTIMER0->PC = 0;
	CTIMER0->MCR |= (1 << 0) | (1 << 1);		//Interrupt on MATCH0 and Reset timer on interrupt MATCH0
	CTIMER0->MR[0] = MATCH0;					// MR0 -> 1ms
	CTIMER0->IR = 1;
	CTIMER0->TCR &= ~(1 << 1 );					//No reset
	NVIC->ISER[0] = (1 << 23); 					// enable interrupt ISE_CT32B0_IRQ

}

uint8_t GetFinPeriodo( void )
{
	return finPeriodo;
}

 void SetFinPeriodo( uint8_t valor  )
{
	finPeriodo = valor;
}
