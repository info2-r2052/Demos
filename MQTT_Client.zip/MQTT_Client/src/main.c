/*
===============================================================================
 Name        : ServoSG90.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#include <mqtt_client.h>


void EnviarVoltaje( void );

int main(void)
{

	uint8_t caracter;

	Inicializar();
	TimerStart(0, 50, EnviarVoltaje, DEC);

    while(1){
    	TimerEvent();
    	caracter = LeerBufferRX();
    	if( caracter != 255 )
    		AnalizarTramaUart1(caracter);


    }
    return 0 ;
}


void EnviarVoltaje( void ){

	uint32_t lecturaPote = ADC_GetCuentas();
	uint8_t buffer[11], aux[11];
	uint8_t chk = 0;
	lecturaPote = (lecturaPote * 3300)/4095;
	sprintf((char*)aux, ">D,%4d,", (int)lecturaPote);
	for( int i = 0; aux[i]; i ++)
		chk ^= aux[i];
	sprintf((char*)buffer, "%s%c<", aux,chk);
	UART1_Send(buffer, strlen((char*)buffer));
	TimerStart(0, 50, EnviarVoltaje, DEC);

}
