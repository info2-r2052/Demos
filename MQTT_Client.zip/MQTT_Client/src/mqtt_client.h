/*
 * ServoSG90.h
 *
 *  Created on: 15 ago. 2021
 *      Author: mariano
 */

#ifndef MQTT_CLIENT_H_
#define MQTT_CLIENT_H_


#include <cr_section_macros.h>
#include "tipos.h"
#include "dr_pll.h"
#include "dr_systick.h"
#include "gpio.h"
#include "io.h"
#include "lcd.h"
#include "ctimer.h"
#include "uart1.h"
#include "teclado.h"
#include "timers.h"
#include "sg90.h"
#include "adc.h"



#define		PERIODOpWM				MATCH0		//24MHz / 20KHz = 1200
#define 	NOVENTAgRADOS			30000
#define 	CEROgRADOS				0
#define 	MENOSnOVENTAgRADOS		90000
#define		SPAN					(NOVENTAgRADOS - MENOSnOVENTAgRADOS)	//12500 (1 ms)
#define		GRADO					SPAN/180	//69,44 (5,55 us por grado)
#define 	REPETICIONgRADOS		9

void Inicializar( void );

#endif /* MQTT_CLIENT_H_ */
