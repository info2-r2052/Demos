# ESP 32 Uart bridge
## Hardware: 
ESP32 Node MCU ESP-32S V1.1 101010
## Connection
```
#define UART_TX_PIN 17  --> P17 NodeMCU (pin 9)
#define UART_RX_PIN 16  --> P16 NodeMCU (pin 8)
```
## Prepare environment variables
export IDF_PATH='/home/marianito/esp/esp-idf'
source $IDF_PATH/export.sh

