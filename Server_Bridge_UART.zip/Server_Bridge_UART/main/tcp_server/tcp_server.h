#pragma once

#define PORTSERVER 10234

void start_tcp_server();
