#include "mainwindow.h"
#include "ui_mainwindow.h"

//#define IPsERVER    "192.168.1.108"
#define IPsERVER    "192.168.7.100"
#define PORTsERVER  10234
#define LED_ERROR    3
#define LED_OK       0
#define LED_WARNING  2
#define LED_BlueOK   1


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), socket(this)
{
    qDebug() << "Constructor\r\n";
    ui->setupUi(this);
    socket.connectToHost(QHostAddress(IPsERVER), PORTsERVER);
    connect(&socket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onReadyRead()
{

    QByteArray data = socket.readAll();



//------Procesamiento de trama-----------
        qint8 localChecksum = 0;
        char cantDelimitadores = 0;
            for( int i=0; data[i]; i++)
            {
                localChecksum ^= data[i]&0xFF;
                if( data[i] == ',' )
                {
                    cantDelimitadores ++;
                    if( cantDelimitadores == 2 )
                        break;
                }
            }
        if( cantDelimitadores == 2 )
            {
                localChecksum &= 0xFF;
                QString respuesta(data);
                QStringList inputArray = respuesta.split(',');
                int parametro = inputArray.at(1).toInt();
                QStringList aux = inputArray.at(2).split('<');

                char checksum = (aux.at(0).at(0).toLatin1()) & 0xFF;
                qDebug() << "aux: " << aux.at(0).toLatin1();

                if( checksum == localChecksum )
                        qDebug() << localChecksum << " es Checksum OK \r\n";
                    else
                        qDebug() << "Error Checksum - Check local: " << localChecksum << "Check remoto: "<< checksum;
                qDebug() << parametro << " contenido parametro\n\r";

                qDebug() << checksum << " contenido checksum\n\r";

                QString bufferRespuesta;
                if( checksum == localChecksum )
                {
                    bufferRespuesta.fromStdString("Recibido OK. Checksum Local: ");
                    bufferRespuesta = bufferRespuesta + QString::number(localChecksum);
                    QByteArray respuesta;
                    QByteArray aux("Recibido OK. Checksum: ");
                    respuesta.setNum(localChecksum);
                    respuesta = aux + respuesta + "\n";
                    ui->lcdNumber->display(parametro);
                    ui->Led->setState(LED_OK);
                    socket.write(">L,R,0,<<");
                    socket.write(">L,G,1,(<");


                }
                else
                {
                    bufferRespuesta.fromStdString("\nError CHK. Checksum Local: ");
                    bufferRespuesta = bufferRespuesta + QString::number(localChecksum);
                    QByteArray respuesta;
                    QByteArray aux("\nError CHK. Checksum Local: ");
                    respuesta.setNum(localChecksum);
                    respuesta = aux + respuesta + "\n";
                    ui->Led->setState(LED_ERROR);
                    socket.write(">L,G,0,)<");
                    socket.write(">L,R,1,=<");


                }
                qDebug() << data;
                qDebug() << "Res" << respuesta;
            }
//------------------------------------------------------

        ui->textEdit->append(data);


}
